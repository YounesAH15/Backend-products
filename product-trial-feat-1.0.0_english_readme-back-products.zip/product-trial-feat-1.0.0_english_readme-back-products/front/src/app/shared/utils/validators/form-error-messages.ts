export const FORM_ERROR_MESSAGES = {
    required: 'Required',
    unknownValue: 'Please select a suggested value',
    emailInvalid: 'Email not valid',
    '*': 'Invalid'
}