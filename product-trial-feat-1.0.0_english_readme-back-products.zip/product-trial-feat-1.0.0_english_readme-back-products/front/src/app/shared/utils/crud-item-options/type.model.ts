export enum TypeInput {
  TEXT = 'text',
  NUMBER = 'number'
}