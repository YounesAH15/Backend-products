export enum ScreenWidth {
  small = 'small', //768,
  medium = 'medium', //1024,
  large = 'large' //1280
}