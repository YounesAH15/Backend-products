import { TooltipOptions } from "primeng/tooltip";

export const TOOLTIP_CONFIG: TooltipOptions = {
  tooltipPosition: 'top'
};
